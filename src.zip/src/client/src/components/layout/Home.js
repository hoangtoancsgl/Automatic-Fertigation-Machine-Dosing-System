import { Redirect } from 'react-router-dom'
const Home = () =>{
    return (
        <Redirect to = '/login'/>
    )
}
export default Home 