const Setting = () => {
  return <div>Settingggggggggggggggggggg</div>;
};
export default Setting;
